
                                                
 _____ _          ____                      _   
|_   _| |_ ___   |    \ ___ ___ ___ ___ ___| |_ 
  | | |   | -_|  |  |  | -_|_ -|  _| -_|   |  _|
  |_| |_|_|___|  |____/|___|___|___|___|_|_|_|  
                                                
                                          
4Kb procedural graphics.
    /With Love

I think I have something with stairwells and brutalist architecture.

Code by: Cedric

Greetings

Doctor Gekil / LLB / Babylon.js team / Guillaume Boisse
Stef / Future Crew / Omar Cornut / Flure / Editions 64K
Jon / Thermostat / Speedman / Evoke orgas / Judge Drokk
Guille / Spectrals / Alex Evans / Spectrals / Totetmatt
Dok / Virgill / Anarchy / Peregrine / Leonard / Flopine
Dune / Divide / NoFrag / G33kou / TRSI / Mooz / Zerkman
Rubix / Triton / Nusan / Alkama / Darya / MrVux / Zavie

And every one I've met at parties !

https://bsky.app/profile/skaven.bsky.social

MMXXV With Love