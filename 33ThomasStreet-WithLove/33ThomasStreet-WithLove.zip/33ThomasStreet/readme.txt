 ______ ______ _______ __                               
|__    |__    |_     _|  |--.-----.--------.---.-.-----.
|__    |__    | |   | |     |  _  |        |  _  |__ --|
|______|______| |___| |__|__|_____|__|__|__|___._|_____|
 _______ __                     __   
|     __|  |_.----.-----.-----.|  |_                                   
|__     |   _|   _|  -__|  -__||   _|        
|_______|____|__| |_____|_____||____|

4Kb procedural graphics.
    /With Love

Yet another brutalist picture. This time with the
fantastic long lines building.

Reproduction of:
https://www.google.com/maps/place/AT%26T+Long+Lines+Building/@40.716264,-74.006094,3a,60y,31.5h,153.6t/data=!3m7!1e1!3m5!1s-w6luiJvIy0thI04D3AavA!2e0!6shttps:%2F%2Fstreetviewpixels-pa.googleapis.com%2Fv1%2Fthumbnail%3Fcb_client%3Dmaps_sv.tactile%26w%3D900%26h%3D600%26pitch%3D-63.602081437073934%26panoid%3D-w6luiJvIy0thI04D3AavA%26yaw%3D31.4986313751636!7i13312!8i6656!4m6!3m5!1s0x89c25a202ed1db59:0x4dc05c3db6cbee58!8m2!3d40.7167971!4d-74.0061116!16s%2Fm%2F02vksqj?entry=ttu&g_ep=EgoyMDI1MTAxNC4wIKXMDSoASAFQAw%3D%3D

Code by: Cedric

Sky shader by drift: https://www.shadertoy.com/view/4tdSWr

Greetings

Doctor Gekil / LLB / Babylon.js team / Guillaume Boisse
Stef / Future Crew / Omar Cornut / Flure / Editions 64K
Jon / Thermostat / Speedman / Evoke orgas / Judge Drokk
Guille / Spectrals / Alex Evans / drift /   / Totetmatt
Dok / Virgill / Anarchy / Peregrine / Leonard / Flopine
Dune / Divide / NoFrag / G33kou / TRSI / Mooz / Zerkman
Rubix / Triton / Nusan / Alkama / Darya / MrVux / Zavie
Team210 /

And every one I've met at parties !

https://bsky.app/profile/skaven.bsky.social

MMXXV With Love