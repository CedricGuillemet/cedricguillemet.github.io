                                                            
88888888ba,                                                 
88      `"8b                                                
88        `8b                                               
88         88  ,adPPYYba,  8b      db      d8  8b,dPPYba,   
88         88  ""     `Y8  `8b    d88b    d8'  88P'   `"8a  
88         8P  ,adPPPPP88   `8b  d8'`8b  d8'   88       88  
88      .a8P   88,    ,88    `8bd8'  `8bd8'    88       88  
88888888Y"'    `"8bbdP"Y8      YP      YP      88       88  
                                                            
                                                            
                                                                   

64Kb intro
    /With Love


 .-.-.  .-.-.  .-.-.  .-.-.  .-.-.  .-.-.  .-.-.  .-.-.  
=`. .'==`. .'==`. .'==`. .'==`. .'==`. .'==`. .'==`. .'=
   "      "      "      "      "      "      "      "   

Code by Cedric
Audio by Doctor Gekil


OpenGL instanced cubes. Old demo I did 10years ago but 
never released... until today!

 .-.-.  .-.-.  .-.-.  .-.-.  .-.-.  .-.-.  .-.-.  .-.-.  
=`. .'==`. .'==`. .'==`. .'==`. .'==`. .'==`. .'==`. .'=
   "      "      "      "      "      "      "      "   

Greetings

Doctor Gekil / LLB / Babylon.js team / Guillaume Boisse
Stef / Future Crew / Omar Cornut / Flure / Editions 64K
Jon / Thermostat / Speedman / Evoke orgas / Judge Drokk
Guille  /  Spectrals / Alex Evans / Team210 / Totetmatt
Dok / Virgill / Anarchy / Peregrine / Leonard / Flopine
Dune / Divide / NoFrag / G33kou / TRSI / Mooz / Zerkman
Rubix / Triton / Nusan  / drift / Darya / MrVux / Zavie 

And every one I've met at parties !

https://bsky.app/profile/skaven.bsky.social

MMXXVI With Love