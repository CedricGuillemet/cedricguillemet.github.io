
   _____ _        _                   _ _ 
  / ____| |      (_)                 | | |
 | (___ | |_ __ _ _ _ ____      _____| | |
  \___ \| __/ _` | | '__\ \ /\ / / _ \ | |
  ____) | || (_| | | |   \ V  V /  __/ | |
 |_____/ \__\__,_|_|_|    \_/\_/ \___|_|_|
                                          
                                          
4K graphics.
    /With Love for Evoke 2025

SDF path traced with 6 bounces and a red omni light.
Textures for some primitives. 256 passes taking a bit
less than a minute on my nVidia 4060. It should be a
bit faster on compo machine.

Credits
Inspired by https://www.tumblr.com/upstairsdownstairsandinbetween/707890235170865152/lew-tolstoi-school-berlin-germany-aff
With a Carpenter Brut/Neo-noir mood.

Using https://github.com/armak/Leviathan-2.0

Code: Cedric
Supply chain manager and Art shaman : Fra

Greetings
Doctor Gekil / Zavie / LLB / Babylon.js team
Thermostat / Guille / Stef / Spectrals / Virgill 
Future Crew / Dune / Divide / NoFrag / Omar Cornut
Guillaume Boisse / Alex Evans / Speedman / G33kou
Spectrals / Flure / Evoke orgas / TRSI / Anarchy
Judge Drokk / Editions 64K / Totetmatt / Peregrine
Rubix / Triton / Leonard / Nusan / Alkama / Flopine
Mooz / Zerkman / Darya / MrVux 
And every one we've met at parties !

https://bsky.app/profile/skaven.bsky.social
https://bsky.app/profile/astrofra.bsky.social

MMXXV With Love